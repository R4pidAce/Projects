﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PalletService
{
    internal class MonthlySbscrp
    {
        string name;
        string LOCATIONID;
        string LOCATIONCODE;
        string PHC;
        string CONTACTPERSON; 
        string TELEPHONE;

        string INTAKENUMBER;
        string SSCC;
        string VARIETY;
        string PACK;
        string MARK;
        string GRADE;
        string INVCODE;
        string PRODCHAR;
        string PICKREF;
        string SIZECOUNT;
        string PUC;
        string ORCHARD;
        string BATCHNO;
        string GTIN;
        string PHCC;
        string OR_ACCOUNT;
        string OR_CONSNO;
        string OR_INTAKEDATESTR;
        string CARTONS;
        string RUNNUMBER;
        string PUNNETS;
        string WEIGHT;
        string XPACK;
        string PALLETQTY;
        string SEQFRACTION;
        string PHYTOSTATUS;
        string RUNNO;
        string TEMPID;
        string PRODGRP;
        string PVARIETY;









        string connetionString;
        SendPallets sendPallets = new SendPallets();

        public void connectDatabase()
        {

            SqlConnection cnn;
            connetionString = @"Data Source=rbrisftp.dedicated.co.za ; Initial Catalog= TRITON ;User ID= rbrisa ;Password= zfpnn2sn7";
            cnn = new SqlConnection(connetionString);
            try
            {
                cnn.Open();
                MessageBox.Show("Connection Open ! ");
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
            }

        }
        private DataTable GetData(string sqlCommand)
        {

            SqlConnection cnn;
            cnn = new SqlConnection(connetionString);

            SqlConnection northwindConnection = new SqlConnection(connetionString);

            SqlCommand command = new SqlCommand(sqlCommand, northwindConnection);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;

            DataTable table = new DataTable();
            table.Locale = System.Globalization.CultureInfo.InvariantCulture;
            adapter.Fill(table);

            return table;
        }


        public  void Siteconfig()
        {
            sendPallets.Siteconfig(name, LOCATIONID, LOCATIONCODE, PHC, CONTACTPERSON, TELEPHONE);

              
            String x = " "; 
            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True;User Instance=True");
            SqlCommand cmd = new SqlCommand("sp_insert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@LOCATIONID", LOCATIONID);
            cmd.Parameters.AddWithValue("@LOCATIONCODE", LOCATIONCODE);
            cmd.Parameters.AddWithValue("@PHC", PHC);
            cmd.Parameters.AddWithValue("@CONTACTPERSON", CONTACTPERSON);
            cmd.Parameters.AddWithValue("@TELEPHONE", TELEPHONE);
            con.Open();
            int i = cmd.ExecuteNonQuery();

            con.Close();

            if (i != 0)
            {
                MessageBox.Show(i + "Data Saved");
            }
        }

        private void PopPallets()
        {
            sendPallets.PopPallets(INTAKENUMBER, SSCC, VARIETY, PACK, MARK, GRADE, INVCODE, PRODCHAR, PICKREF, SIZECOUNT, PUC, ORCHARD, BATCHNO, GTIN, PHCC, OR_ACCOUNT,
             OR_CONSNO, OR_INTAKEDATESTR, CARTONS, RUNNUMBER, PUNNETS, WEIGHT, XPACK, PALLETQTY, SEQFRACTION, PHYTOSTATUS, RUNNO, TEMPID, PRODGRP, PVARIETY);

            String x = " ";
            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True;User Instance=True");
            SqlCommand cmd = new SqlCommand("sp_insert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@INTAKENUMBER", INTAKENUMBER);
            cmd.Parameters.AddWithValue("@SSCC", SSCC);
            cmd.Parameters.AddWithValue("@VARIETY", VARIETY);
            cmd.Parameters.AddWithValue("@PACK", PACK);
            cmd.Parameters.AddWithValue("@MARK", MARK);
            cmd.Parameters.AddWithValue("@GRADE", GRADE);
            cmd.Parameters.AddWithValue("@INVCODE", INVCODE);
            cmd.Parameters.AddWithValue("@PRODCHAR", PRODCHAR);
            cmd.Parameters.AddWithValue("@PICKREF", PICKREF);
            cmd.Parameters.AddWithValue("@SIZECOUNT", SIZECOUNT);
            cmd.Parameters.AddWithValue("@PUC", PUC);
            cmd.Parameters.AddWithValue("@ORCHARD", ORCHARD);
            cmd.Parameters.AddWithValue("@BATCHNO", BATCHNO);
            cmd.Parameters.AddWithValue("@GTIN", GTIN);
            cmd.Parameters.AddWithValue("@PHC", PHCC);
            cmd.Parameters.AddWithValue("@OR_ACCOUNT", OR_ACCOUNT);
            cmd.Parameters.AddWithValue("@OR_CONSNO", OR_CONSNO);
            cmd.Parameters.AddWithValue("@OR_INTAKEDATESTR", OR_INTAKEDATESTR);
            cmd.Parameters.AddWithValue("@CARTONS", CARTONS);
            cmd.Parameters.AddWithValue("@RUNNUMBER", RUNNUMBER);
            cmd.Parameters.AddWithValue("@PUNNETS", PUNNETS);
            cmd.Parameters.AddWithValue("@WEIGHT", WEIGHT);
            cmd.Parameters.AddWithValue("@XPACK", XPACK);
            cmd.Parameters.AddWithValue("@PALLETQTY", PALLETQTY);
            cmd.Parameters.AddWithValue("@SEQFRACTION", SEQFRACTION);
            cmd.Parameters.AddWithValue("@PHYTOSTATUS", PHYTOSTATUS);
            cmd.Parameters.AddWithValue("@RUNNO", RUNNO);
            cmd.Parameters.AddWithValue("@TEMPID", TEMPID);
            cmd.Parameters.AddWithValue("@PRODGRP", PRODGRP);
            cmd.Parameters.AddWithValue("@PVARIETY", PVARIETY);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i != 0)
            {
                MessageBox.Show(i + "Data Saved");
            }
        }

    }
}
