﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.IO.Ports;

namespace PalletService
{
    internal class SendPallets
    {
        private string LocalserverName;
        private string LocalDatabaseName;
        string connetionString;


        private void ConfigFile()
        {
            int counter = 0;
            string fileName = @"C:\TRITON\TRITON.INI";
            foreach (string line in System.IO.File.ReadLines(fileName))
            {
                if (line.StartsWith("SERVER"))
                {
                    LocalserverName = line.Remove(0, 7);
                }
                if (line.StartsWith("DATABASE1"))
                {
                    LocalDatabaseName = line.Remove(0, 10);

                }
                counter++;
            }

        }

        public void connectDatabase()
        {
            ConfigFile();
            SqlConnection cnn;
            connetionString = @"Data Source=" + LocalserverName + ";Initial Catalog= " + LocalDatabaseName + ";User ID=;Password=";
            cnn = new SqlConnection(connetionString);
            try
            {
                cnn.Open();
                MessageBox.Show("Connection Open ! ");
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
            }
        }


        private DataTable GetData(string sqlCommand)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=" + LocalserverName + ";Initial Catalog= " + LocalDatabaseName + ";User ID=;Password=";
            cnn = new SqlConnection(connetionString);

            SqlConnection northwindConnection = new SqlConnection(connetionString);

            SqlCommand command = new SqlCommand(sqlCommand, northwindConnection);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;

            DataTable table = new DataTable();
            table.Locale = System.Globalization.CultureInfo.InvariantCulture;
            adapter.Fill(table);

            return table;
        }


        public void Siteconfig(string name, string LOCATIONID, string LOCATIONCODE, string PHC, string CONTACTPERSON, string TELEPHONE)
        {
            name = GetData("SELECT NAME FROM SITECONFIGURATION").ToString();
            LOCATIONID = GetData("SELECT LOCATIONID FROM SITECONFIGURATION").ToString();
            LOCATIONCODE = GetData("SELECT LOCATIONCODE FROM SITECONFIGURATION").ToString();
            PHC = GetData("SELECT PHC FROM SITECONFIGURATION").ToString();
            CONTACTPERSON = GetData("SELECT CONTACTPERSON FROM SITECONFIGURATION").ToString();
            TELEPHONE = GetData("SELECT TELEPHONE FROM SITECONFIGURATION").ToString();
        }

        public void PopPallets(string INTAKENUMBER, string SSCC, string VARIETY, string PACK, string MARK, string GRADE, string INVCODE, string PRODCHAR,string PICKREF, string SIZECOUNT, string PUC, string ORCHARD, string BATCHNO, string GTIN, string PHC, string OR_ACCOUNT, 
            string OR_CONSNO,string OR_INTAKEDATESTR, string CARTONS, string RUNNUMBER, string PUNNETS, string WEIGHT, string XPACK, string PALLETQTY, string SEQFRACTION, string PHYTOSTATUS,string RUNNO, string TEMPID, string PRODGRP, string PVARIETY)
        {
            INTAKENUMBER = GetData("SELECT INTAKENUMBER FROM INTAKEPALLETDETAIL").ToString();
            SSCC = GetData("SELECT SSCC FROM INTAKEPALLETDETAIL").ToString();
            VARIETY = GetData("SELECT VARIETY FROM INTAKEPALLETDETAIL").ToString();
            PACK = GetData("SELECT PACK FROM INTAKEPALLETDETAIL").ToString();
            MARK = GetData("SELECT MARK FROM INTAKEPALLETDETAIL").ToString();
            GRADE = GetData("SELECT GRADE FROM INTAKEPALLETDETAIL").ToString();
            INVCODE = GetData("SELECT INTAKENUMBER FROM INTAKEPALLETDETAIL").ToString();
            PRODCHAR = GetData("SELECT PRODCHAR FROM INTAKEPALLETDETAIL").ToString();
            PICKREF = GetData("SELECT PICKREF FROM INTAKEPALLETDETAIL").ToString();
            SIZECOUNT = GetData("SELECT SIZECOUNT FROM INTAKEPALLETDETAIL").ToString();
            PUC = GetData("SELECT PUC FROM INTAKEPALLETDETAIL").ToString();
            ORCHARD = GetData("SELECT ORCHARD FROM INTAKEPALLETDETAIL").ToString();
            BATCHNO = GetData("SELECT BATCHNO FROM INTAKEPALLETDETAIL").ToString();
            GTIN = GetData("SELECT GTIN FROM INTAKEPALLETDETAIL").ToString();
            PHC = GetData("SELECT PHC FROM INTAKEPALLETDETAIL").ToString();
            OR_CONSNO = GetData("SELECT OR_CONSNO FROM INTAKEPALLETDETAIL").ToString();
            OR_INTAKEDATESTR = GetData("SELECT OR_INTAKEDATESTR FROM INTAKEPALLETDETAIL").ToString();
            CARTONS = GetData("SELECT CARTONS FROM INTAKEPALLETDETAIL").ToString();
            RUNNUMBER = GetData("SELECT RUNNUMBER FROM INTAKEPALLETDETAIL").ToString();
            PUNNETS = GetData("SELECT PUNNETS FROM INTAKEPALLETDETAIL").ToString();
            WEIGHT = GetData("SELECT WEIGHT FROM INTAKEPALLETDETAIL").ToString();
            XPACK = GetData("SELECT XPACK FROM INTAKEPALLETDETAIL").ToString();
            PALLETQTY = GetData("SELECT PALLETQTY FROM INTAKEPALLETDETAIL").ToString();
            SEQFRACTION = GetData("SELECT SEQFRACTION FROM INTAKEPALLETDETAIL").ToString();
            PHYTOSTATUS = GetData("SELECT PHYTOSTATUS FROM INTAKEPALLETDETAIL").ToString();
            RUNNO = GetData("SELECT RUNNO FROM INTAKEPALLETDETAIL").ToString();
            TEMPID = GetData("SELECT TEMPID FROM INTAKEPALLETDETAIL").ToString();
            PRODGRP = GetData("SELECT PRODGRP FROM INTAKEPALLETDETAIL").ToString();
            PVARIETY = GetData("SELECT PVARIETY FROM INTAKEPALLETDETAIL").ToString();

        }

        public  void date(DateTime ENDdate)
        {
            ENDdate = DateTime.Parse(GetData("SELECT ENDDATESTR FROM SITECONFIGURATION").ToString());
        }
    }
}
