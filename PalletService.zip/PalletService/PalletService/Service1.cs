﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PalletService
{
    public partial class Service1 : ServiceBase
    {


        [DllImport("wininet.dll")]
        //Checks for internet connection and returns bool value
        private extern static bool InternetGetConnectedState(out int Description, int ReservedValue);

        SendPallets sendPallets = new SendPallets();
        MonthlySbscrp monthlySbscrp = new MonthlySbscrp();
        public Service1()
        {
            InitializeComponent();
            this.ServiceName = "WindowsService.NET";
            OnStart(null);

        }

        protected override void OnStart(string[] args)
        {
            internetCheck();

        }

        protected override void OnStop()
        {

        }

        public void internetCheck()
        {
            int Desc;
            if (InternetGetConnectedState(out Desc, 0) == true)
            {
                sendPallets.connectDatabase();
                monthlySbscrp.Siteconfig();
            }
        }


    }
}
