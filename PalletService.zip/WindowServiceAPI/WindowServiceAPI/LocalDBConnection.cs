﻿using System.Data.SqlClient;
using System.Data;
using System.Runtime.InteropServices;
using System.Windows;
namespace WindowServiceAPI
{
    public class LocalDBConnection
    {
        private static string serverName;
        private static string DatabaseName;
      
        [DllImport("wininet.dll")]
        //Checks for internet connection and returns bool value
        private extern static bool InternetGetConnectedState(out int Description, int ReservedValue);



        public LocalDBConnection()
        {
      
        }
        public void ConfigFile()
        {
            int counter = 0;
            string fileName = @"C:\TRITON\TRITON.INI";
            foreach (string line in System.IO.File.ReadLines(fileName))
            {
                if (line.StartsWith("SERVER"))
                {
                    serverName = line.Remove(0, 7);

                }
                if (line.StartsWith("DATABASE1"))
                {
                    DatabaseName = line.Remove(0, 10);

                }
                counter++;
            }

        }

        public void connectDatabase()
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=" + serverName + ";Initial Catalog= " + DatabaseName + ";User ID=;Password=";
            cnn = new SqlConnection(connetionString);
            try
            {
                cnn.Open();
            //    MessageBox.Show("Connection Open ! ");
                cnn.Close();
            }
            catch (Exception ex)
            {
            //    MessageBox.Show("Can not open connection ! ");
            }

        }
        public void internetCheck()
        {
            int Desc;
            if (InternetGetConnectedState(out Desc, 0) == true)
            {
                connectDatabase();
            /*    MessageBox.Show(GetData("Select * From INTAKEPALLET").ToString());
                MessageBox.Show(GetData("Select * From INTAKEPALLETDETAIL").ToString());
                MessageBox.Show(GetData("Select * From SITECONFIGURATION").ToString());
*/
            }
        }

        private static DataTable GetData(string sqlCommand)
        {
            string connetionString;
            SqlConnection cnn;
            connetionString = @"Data Source=(LocalDB)\MSSQLLocalDB" + ";Initial Catalog= TRITON22;User ID=;Password=";
            cnn = new SqlConnection(connetionString);

            SqlConnection northwindConnection = new SqlConnection(connetionString);

            SqlCommand command = new SqlCommand(sqlCommand, northwindConnection);
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;

            DataTable table = new DataTable();
            table.Locale = System.Globalization.CultureInfo.InvariantCulture;
            adapter.Fill(table);

            return table;
        }
    }
}
